export const URL = 'http://mmg-score.herokuapp.com';
export const NUMBER_FOR_PAIR = 2;
export const FIRST_CARD_TO_CHECK = 0;
export const SECOND_CARD_TO_CHECK = 1;
export const TIME_FOR_ANIMATION = 1500;
export const TOP_OF_SCORE_FOR_RENDER = 10;