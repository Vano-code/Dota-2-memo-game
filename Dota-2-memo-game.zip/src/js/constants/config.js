export const Config = {
    diff: [{
            width: 4,
            height: 3
        },
        {
            width: 6,
            height: 4
        },
        {
            width: 8,
            height: 4
        },
    ],
    shirts: [
        'shirt_1.png',
        'shirt_2.png',
        'shirt_3.png',
        'shirt_4.png',
        'shirt_5.png',
        'shirt_6.png',
        'shirt_7.png',
        'shirt_8.png',
        'shirt_9.png',
        'shirt_10.png',
        'shirt_11.png',
        'shirt_12.png',
        'shirt_13.png',
        'shirt_14.png',
        'shirt_15.png',
        'shirt_16.png'
    ],
    backs: [
        'back_1.png',
        'back_2.png',
        'back_3.png',
        'back_4.png',
    ]
}