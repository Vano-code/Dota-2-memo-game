In this game you must find two identical cards
GLHF (good luck have fun)
STAN IVAN
